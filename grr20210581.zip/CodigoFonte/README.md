# corra-das-fake-news
Trabalho 1 de Paradigmas de Programação
Falta tratar exeções no comando "teleportar" em que o jogador teletransporta e depois pode se movimentar não sofrendo punições.
