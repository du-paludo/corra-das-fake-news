public interface Movimento {
    public boolean movimenta(int movimento);
}